/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */

#ifndef SOCKS5_SERVER_H
#define SOCKS5_SERVER_H

#include <aws/io/io.h>

#include <aws/common/byte_buf.h>
#include <aws/common/condition_variable.h>
#include <aws/common/hash_table.h>
#include <aws/common/mutex.h>
#include <aws/common/ref_count.h>
#include <aws/common/string.h>
#include <aws/io/channel.h>
#include <aws/io/channel_bootstrap.h>
#include <aws/io/event_loop.h>
#include <aws/io/socket.h>

#ifndef AWS_UNSTABLE_TESTING_API
#    error This code is designed for use by AWS owned libraries for the AWS C99 SDK. \
You are welcome to use it, but we make no promises on the stability of this API. \
To enable use of this code, set the AWS_UNSTABLE_TESTING_API compiler flag.
#endif

struct aws_socks5_server;

/****** Public types ******/

/** tells the server to fail in particular ways */
enum aws_socks5_server_fault_mode {

    /** don't fail, default */
    AWS_SOCKS5_SFM_NONE,

    /** send back a bad version code in the hello response */
    AWS_SOCKS5_SFM_BAD_VERSION,

    /** don't try to connect to the remote, just send a response that says it's unavailable */
    AWS_SOCKS5_SFM_REMOTE_UNAVAILABLE,

    /** don't try to connect to the remote, just do nothing (and generate a timeout) */
    AWS_SOCKS5_SFM_REMOTE_TIMEOUT,
};

/**
 * Configuration options for socks5 server authentication controls
 */
struct aws_socks5_server_auth_options {

    /**
     * Is the None authentication method supported?
     */
    bool allow_no_auth;

    /**
     * Is basic authentication supported?
     */
    bool allow_basic_auth;

    /**
     * If basic authentication is enabled, what username is valid?
     */
    struct aws_byte_cursor *basic_username;

    /**
     * If basic authentication is enabled, what password is valid?
     */
    struct aws_byte_cursor *basic_password;
};

typedef void(aws_socks5_server_on_setup_fn)(struct aws_socks5_server *server, int error_code, void *user_data);
typedef void(aws_socks5_server_on_destroy_fn)(struct aws_socks5_server *server, void *user_data);

/**
 * Configuration options for creating a socks5 server
 */
struct aws_socks5_server_options {

    /**
     * Event loop group to use for socket listener and tunnel channels
     */
    struct aws_event_loop_group *elg;

    /**
     * Client bootstrap to use when establishing a connection to remote endpoints
     */
    struct aws_client_bootstrap *to_remote_bootstrap;

    /**
     * Server bootstrap to use when creating the socket listener
     */
    struct aws_server_bootstrap *listener_bootstrap;

    /**
     * Host to listen on
     */
    const char *host_name;

    /**
     * Port to listen on.  Use zero to have an open port assigned at accept-time.
     */
    uint16_t port;

    /**
     * Socket options to use for listener and remote connections.  Not all options are valid.
     */
    struct aws_socket_options socket_options;

    /**
     * What authentication methods should be supported during socks5 negotiation
     */
    struct aws_socks5_server_auth_options auth_options;

    /**
     * Any special failure directive for testing purposes
     */
    enum aws_socks5_server_fault_mode fault_mode;

    /**
     * Callback to invoke when the socket listener has been set up
     */
    aws_socks5_server_on_setup_fn *on_setup;

    /**
     * Callback to invoke when the server has been fully destroyed
     */
    aws_socks5_server_on_destroy_fn *on_destroy;

    /**
     * Opaque data to pass to callbacks
     */
    void *user_data;
};

/**
 * Configuration options for a socks5 server wrapper that adds wait functionality
 */
struct aws_socks5_server_test_context_options {
    struct aws_event_loop_group *elg;

    struct aws_socks5_server_auth_options *override_auth_options;

    enum aws_socks5_server_fault_mode fault_mode;
};

struct aws_socks5_server_test_context {
    struct aws_allocator *allocator;

    struct aws_event_loop_group *elg;
    struct aws_host_resolver *resolver;
    struct aws_client_bootstrap *client_bootstrap;
    struct aws_server_bootstrap *server_bootstrap;

    struct aws_mutex lock;
    struct aws_condition_variable signal;
    struct {
        bool server_setup;
        int setup_error_code;
        bool server_shutdown;
    } sync;

    struct aws_socks5_server *server;
};

AWS_EXTERN_C_BEGIN

/****** Public API ******/

/**
 * Creates a new socks5 server
 *
 * @param allocator allocator to use
 * @param options server configuration options
 */
static struct aws_socks5_server *aws_socks5_server_new(
    struct aws_allocator *allocator,
    struct aws_socks5_server_options *options);

/**
 * Adds a reference to a socks5 server
 *
 * @param server server to add a reference to
 * @return the server input param value
 */
static struct aws_socks5_server *aws_socks5_server_acquire(struct aws_socks5_server *server);

/**
 * Removes a reference from a socks5 server
 *
 * @param server server to remove a reference from
 */
static void aws_socks5_server_release(struct aws_socks5_server *server);

/**
 * Trigger the server to start listening for incoming connection requests
 *
 * @param server server to begin listening on
 * @return success/failure
 */
static int aws_socks5_server_begin_accept(struct aws_socks5_server *server);

/**
 * Gets what port the server is listening on; will crash if the server is not listening
 *
 * @param server server to query the listener port for
 * @return the port the server is listening on
 */
static uint32_t aws_socks5_server_get_listener_port(struct aws_socks5_server *server);

/**
 * Gets how many tunnels have been created over the server's lifetime.  Useful as a simple verification that a test
 * is actually connecting through the server and not skipping it.
 *
 * @param server server to check tunnel creation count for
 * @return total number of tunnels created so far
 */
static size_t aws_socks5_server_get_connections_created(struct aws_socks5_server *server);

/**
 * Initialize a test context that wraps a socks5 server with wait functionality
 *
 * @param context context to initialize
 * @param allocator allocator to use
 * @param options context configuration options
 */
static void aws_socks5_server_test_context_init(
    struct aws_socks5_server_test_context *context,
    struct aws_allocator *allocator,
    struct aws_socks5_server_test_context_options *options);

/**
 * Cleans up a socks5 server test context.  This includes shutting down the listener socket, destroying all
 * active tunnels and waiting for final server destruction.
 *
 * @param context test context to clean up
 */
static void aws_socks5_server_test_context_clean_up(struct aws_socks5_server_test_context *context);

/**
 * Waits for a context's socks5 server to finish setting up its socket listener.  accept must have been called
 * earlier.
 *
 * @param context test context to wait on
 */
static void aws_socks5_server_test_context_wait_on_server_setup(struct aws_socks5_server_test_context *context);

/****** Implementation ******/

struct aws_socks5_server_auth_config {
    struct aws_allocator *allocator;

    bool allow_no_auth;
    bool allow_basic_auth;
    struct aws_byte_buf basic_username;
    struct aws_byte_buf basic_password;
};

struct aws_socks5_server_config {
    struct aws_allocator *allocator;

    struct aws_event_loop_group *elg;
    struct aws_client_bootstrap *to_remote_bootstrap;
    struct aws_server_bootstrap *listener_bootstrap;

    struct aws_string *host_name;
    uint16_t port;

    struct aws_socket_options socket_options;

    struct aws_socks5_server_auth_config *auth_config;

    enum aws_socks5_server_fault_mode fault_mode;

    aws_socks5_server_on_setup_fn *on_setup;
    aws_socks5_server_on_destroy_fn *on_destroy;

    void *user_data;
};

enum aws_socks5_server_state {
    AWS_SOCKS5_SS_INITIAL,
    AWS_SOCKS5_SS_PENDING_LISTENER,
    AWS_SOCKS5_SS_LISTENING,
    AWS_SOCKS5_SS_SHUTTING_DOWN,
    AWS_SOCKS5_SS_SHUTDOWN,
};

struct aws_socks5_server {
    struct aws_allocator *allocator;

    struct aws_ref_count external_ref_count;

    /*
     * Internal Ref Cases:
     *  1. External ref count holds one internal ref while non-zero
     *  2. The listener socket holds a ref while alive
     *  3. Each tunnel holds an internal ref
     */
    struct aws_ref_count internal_ref_count;

    struct aws_socks5_server_config *config;

    struct aws_mutex lock;

    struct {
        enum aws_socks5_server_state state;
        uint64_t next_id;
        struct aws_hash_table tunnels_by_id;
        struct aws_socket *listener_socket;
        size_t connections_created_count;
    } sync;
};

enum aws_socks5_tunnel_state {
    AWS_SOCKS5_TS_PENDING_METHOD_LIST,
    AWS_SOCKS5_TS_PENDING_BASIC_AUTH_RECORD,
    AWS_SOCKS5_TS_PENDING_COMMAND,
    AWS_SOCKS5_TS_PENDING_REMOTE_CONNECTION,
    AWS_SOCKS5_TS_PASS_THROUGH,
    AWS_SOCKS5_TS_SHUTTING_DOWN,
    AWS_SOCKS5_TS_SHUTDOWN,
};

enum aws_socks5_auth_method_ids {
    AWS_SOCKS5_AMI_NONE = 0x00,
    AWS_SOCKS5_AMI_BASIC = 0x02,
    AWS_SOCSK5_AMI_NO_ACCEPTABLE = 0xFF
};

enum aws_socks5_command_ids {
    AWS_SOCKS5_COMMAND_CONNECT = 0x01,
    AWS_SOCKS5_COMMAND_BIND = 0x02,
    AWS_SOCKS5_COMMAND_ASSOCIATE = 0x03,
};

enum aws_socks5_address_type {
    AWS_SOCKS5_AT_IPV4 = 0x01,
    AWS_SOCKS5_AT_DOMAIN_NAME = 0x03,
    AWS_SOCKS5_AT_IPV6 = 0x04,
};

enum aws_socks5_connect_response_code {
    AWS_SOCKS5_CRC_SUCCEEDED = 0x00,
    AWS_SOCKS5_CRC_HOST_UNREACHABLE = 0x04,
};

struct aws_socks5_tunnel {
    struct aws_allocator *allocator;

    struct aws_ref_count ref_count;

    uint64_t id;

    struct aws_socks5_server *server;

    enum aws_socks5_tunnel_state state;

    enum aws_socks5_auth_method_ids selected_auth_method;

    struct aws_string *remote_host_name;
    uint16_t remote_port;

    struct aws_event_loop *event_loop;

    struct aws_channel *to_client;
    struct aws_channel_handler to_client_handler;

    struct aws_channel *to_remote;
    struct aws_channel_handler to_remote_handler;

    struct aws_byte_buf handshake_data;

    int shutdown_error_code;

    bool pending_remote;
    void (*on_shutdown)(struct aws_socks5_tunnel *tunnel, int error_code, void *user_data);
    void *on_shutdown_user_data;
};

static struct aws_socks5_server_auth_config *s_aws_socks5_server_auth_config_new(
    struct aws_allocator *allocator,
    struct aws_socks5_server_auth_options *options) {

    struct aws_socks5_server_auth_config *config = (struct aws_socks5_server_auth_config *)aws_mem_calloc(
        allocator, 1, sizeof(struct aws_socks5_server_auth_config));

    config->allocator = allocator;

    if (options != NULL) {
        config->allow_no_auth = options->allow_no_auth;
        config->allow_basic_auth = options->allow_basic_auth;

        if (options->allow_basic_auth) {
            if (options->basic_username) {
                aws_byte_buf_init_copy_from_cursor(&config->basic_username, allocator, *options->basic_username);
            }

            if (options->basic_password) {
                aws_byte_buf_init_copy_from_cursor(&config->basic_password, allocator, *options->basic_password);
            }
        }
    }

    return config;
}

static void s_aws_socks5_server_auth_config_destroy(struct aws_socks5_server_auth_config *config) {
    if (config == NULL) {
        return;
    }

    aws_byte_buf_clean_up(&config->basic_username);
    aws_byte_buf_clean_up(&config->basic_password);

    aws_mem_release(config->allocator, config);
}

static struct aws_socks5_server_config *s_aws_socks5_server_config_new(
    struct aws_allocator *allocator,
    struct aws_socks5_server_options *options) {

    struct aws_socks5_server_config *config =
        (struct aws_socks5_server_config *)aws_mem_calloc(allocator, 1, sizeof(struct aws_socks5_server_config));

    config->allocator = allocator;
    config->elg = aws_event_loop_group_acquire(options->elg);
    config->to_remote_bootstrap = aws_client_bootstrap_acquire(options->to_remote_bootstrap);
    config->listener_bootstrap = aws_server_bootstrap_acquire(options->listener_bootstrap);
    config->host_name = aws_string_new_from_c_str(allocator, options->host_name);
    config->port = options->port;
    config->socket_options = options->socket_options;
    config->auth_config = s_aws_socks5_server_auth_config_new(allocator, &options->auth_options);
    config->on_setup = options->on_setup;
    config->on_destroy = options->on_destroy;
    config->user_data = options->user_data;
    config->fault_mode = options->fault_mode;

    return config;
}

static void s_aws_socks5_server_config_destroy(struct aws_socks5_server_config *config) {
    if (config == NULL) {
        return;
    }

    s_aws_socks5_server_auth_config_destroy(config->auth_config);

    aws_string_destroy(config->host_name);

    aws_event_loop_group_release(config->elg);
    aws_client_bootstrap_release(config->to_remote_bootstrap);
    aws_server_bootstrap_release(config->listener_bootstrap);

    aws_mem_release(config->allocator, config);
}

static void s_aws_socks5_tunnel_update_error_code(struct aws_socks5_tunnel *tunnel, int error_code) {
    if (tunnel->shutdown_error_code == AWS_ERROR_SUCCESS) {
        tunnel->shutdown_error_code = error_code;
    }
}

static void s_aws_socks5_tunnel_change_state(struct aws_socks5_tunnel *tunnel, enum aws_socks5_tunnel_state new_state) {
    tunnel->state = new_state;
    aws_byte_buf_reset(&tunnel->handshake_data, false);
}

static void s_aws_socks5_tunnel_on_channel_destroyed(struct aws_socks5_tunnel *tunnel, struct aws_channel *channel) {
    AWS_FATAL_ASSERT(aws_event_loop_thread_is_callers_thread(tunnel->event_loop));

    if (tunnel->to_remote == channel) {
        tunnel->to_remote = NULL;
    }

    if (tunnel->to_client == channel) {
        tunnel->to_client = NULL;
    }

    if (tunnel->to_remote == NULL && tunnel->to_client == NULL && !tunnel->pending_remote) {
        s_aws_socks5_tunnel_change_state(tunnel, AWS_SOCKS5_TS_SHUTDOWN);
        (*tunnel->on_shutdown)(tunnel, tunnel->shutdown_error_code, tunnel->on_shutdown_user_data);
    }
}

struct aws_socks5_tunnel_shutdown_task {
    struct aws_allocator *allocator;

    struct aws_task task;

    struct aws_socks5_tunnel *tunnel;
    int error_code;
};

static void s_aws_socks5_tunnel_shutdown_task_destroy(struct aws_socks5_tunnel_shutdown_task *task) {
    aws_ref_count_release(&task->tunnel->ref_count);
    aws_mem_release(task->allocator, task);
}

static void s_aws_socks5_tunnel_shut_down(struct aws_socks5_tunnel *tunnel, int error_code) {
    AWS_FATAL_ASSERT(aws_event_loop_thread_is_callers_thread(tunnel->event_loop));

    if (tunnel->state == AWS_SOCKS5_TS_SHUTTING_DOWN || tunnel->state == AWS_SOCKS5_TS_SHUTDOWN) {
        return;
    }

    tunnel->state = AWS_SOCKS5_TS_SHUTTING_DOWN;

    s_aws_socks5_tunnel_update_error_code(tunnel, error_code);

    if (tunnel->to_remote) {
        aws_channel_shutdown(tunnel->to_remote, tunnel->shutdown_error_code);
    }

    if (tunnel->to_client) {
        aws_channel_shutdown(tunnel->to_client, tunnel->shutdown_error_code);
    }

    s_aws_socks5_tunnel_on_channel_destroyed(tunnel, NULL);
}

static void s_aws_socks5_tunnel_shutdown_task_fn(struct aws_task *task, void *arg, enum aws_task_status status) {
    (void)task;

    struct aws_socks5_tunnel_shutdown_task *shutdown_task = (struct aws_socks5_tunnel_shutdown_task *)arg;
    struct aws_socks5_tunnel *tunnel = NULL;

    if (status == AWS_TASK_STATUS_CANCELED) {
        goto done;
    }

    tunnel = shutdown_task->tunnel;

    s_aws_socks5_tunnel_shut_down(tunnel, shutdown_task->error_code);

done:

    s_aws_socks5_tunnel_shutdown_task_destroy(shutdown_task);
}

static struct aws_socks5_tunnel_shutdown_task *s_aws_socks5_tunnel_shutdown_task_new(
    struct aws_allocator *allocator,
    struct aws_socks5_tunnel *tunnel,
    int error_code) {

    struct aws_socks5_tunnel_shutdown_task *task = (struct aws_socks5_tunnel_shutdown_task *)aws_mem_calloc(
        allocator, 1, sizeof(struct aws_socks5_tunnel_shutdown_task));
    task->allocator = allocator;
    task->tunnel = tunnel;
    aws_ref_count_acquire(&tunnel->ref_count);
    task->error_code = error_code;

    aws_task_init(&task->task, s_aws_socks5_tunnel_shutdown_task_fn, task, "socks5tunnelshutdown");

    return task;
}

static void s_aws_socks5_tunnel_shutdown(struct aws_socks5_tunnel *tunnel, int error_code) {
    struct aws_socks5_tunnel_shutdown_task *task =
        s_aws_socks5_tunnel_shutdown_task_new(tunnel->allocator, tunnel, error_code);

    aws_event_loop_schedule_task_now_serialized(tunnel->event_loop, &task->task);
}

// Server Reference Semantics
//
// External ref count - starts at 1 (the caller of _new(...)), external holders only
//
// Internal ref count - starts at 1 (the external ref count being non zero)
//    Listener start to final destruction - holds 1
//    Every tunnel - holds 1
//
// Don't dec the internal ref count while holding the lock

static void s_shut_down_server(struct aws_socks5_server *server) {

    struct aws_socket *listener = NULL;

    aws_mutex_lock(&server->lock);

    // shut down listener, wait for shutdown callback
    switch (server->sync.state) {
        case AWS_SOCKS5_SS_PENDING_LISTENER:
            server->sync.state = AWS_SOCKS5_SS_SHUTTING_DOWN;
            // can't do anything, have to wait for async listener to complete and then shut it down in the callback
            break;

        case AWS_SOCKS5_SS_LISTENING:
            server->sync.state = AWS_SOCKS5_SS_SHUTTING_DOWN;
            listener = server->sync.listener_socket;
            server->sync.listener_socket = NULL;
            break;

        case AWS_SOCKS5_SS_INITIAL:
            server->sync.state = AWS_SOCKS5_SS_SHUTDOWN;
            break;

        default:
            // do nothing (shutting down, shut down)
            break;
    }

    struct aws_array_list tunnels;
    aws_array_list_init_dynamic(
        &tunnels,
        server->allocator,
        aws_hash_table_get_entry_count(&server->sync.tunnels_by_id),
        sizeof(struct aws_socks5_tunnel *));

    for (struct aws_hash_iter iter = aws_hash_iter_begin(&server->sync.tunnels_by_id); !aws_hash_iter_done(&iter);
         aws_hash_iter_next(&iter)) {
        struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)iter.element.value;

        aws_array_list_push_back(&tunnels, &tunnel);
        aws_ref_count_acquire(&tunnel->ref_count);
    }

    aws_mutex_unlock(&server->lock);

    if (listener) {
        aws_server_bootstrap_destroy_socket_listener(server->config->listener_bootstrap, listener);
    }

    for (size_t i = 0; i < aws_array_list_length(&tunnels); i++) {
        struct aws_socks5_tunnel *tunnel = NULL;
        aws_array_list_get_at(&tunnels, &tunnel, i);

        s_aws_socks5_tunnel_shutdown(tunnel, AWS_ERROR_EXTERNAL_REQUEST_SHUTDOWN);
        aws_ref_count_release(&tunnel->ref_count);
    }

    aws_array_list_clean_up(&tunnels);
}

static void s_on_server_external_ref_count_zero(void *user_data) {
    struct aws_socks5_server *server = (struct aws_socks5_server *)user_data;

    s_shut_down_server(server);

    // External ref count holds one internal ref
    aws_ref_count_release(&server->internal_ref_count); // Internal Ref Case 1
}

static void s_on_server_internal_ref_count_zero(void *user_data) {

    struct aws_socks5_server *server = (struct aws_socks5_server *)user_data;

    aws_mutex_clean_up(&server->lock);

    AWS_FATAL_ASSERT(aws_hash_table_get_entry_count(&server->sync.tunnels_by_id) == 0);

    aws_hash_table_clean_up(&server->sync.tunnels_by_id);

    if (server->config->on_destroy) {
        (*server->config->on_destroy)(server, server->config->user_data);
    }

    s_aws_socks5_server_config_destroy(server->config);

    aws_mem_release(server->allocator, server);
}

static void s_aws_socks5_server_init_vtables(void);

static struct aws_socks5_server *aws_socks5_server_new(
    struct aws_allocator *allocator,
    struct aws_socks5_server_options *options) {

    s_aws_socks5_server_init_vtables();

    struct aws_socks5_server *server =
        (struct aws_socks5_server *)aws_mem_calloc(allocator, 1, sizeof(struct aws_socks5_server));

    server->allocator = allocator;

    aws_ref_count_init(&server->external_ref_count, server, s_on_server_external_ref_count_zero);
    aws_ref_count_init(&server->internal_ref_count, server, s_on_server_internal_ref_count_zero); // Internal Ref Case 1

    server->config = s_aws_socks5_server_config_new(allocator, options);

    aws_mutex_init(&server->lock);

    server->sync.state = AWS_SOCKS5_SS_INITIAL;
    server->sync.next_id = 1;
    aws_hash_table_init(
        &server->sync.tunnels_by_id,
        allocator,
        4,
        aws_hash_uint64_t_by_identity,
        aws_hash_compare_uint64_t_eq,
        NULL,
        NULL);

    return server;
}

static struct aws_socks5_server *aws_socks5_server_acquire(struct aws_socks5_server *server) {
    if (server) {
        aws_ref_count_acquire(&server->external_ref_count);
    }

    return server;
}

static void aws_socks5_server_release(struct aws_socks5_server *server) {
    aws_ref_count_release(&server->external_ref_count);
}

static void s_aws_socks5_server_bootstrap_on_listener_setup_fn(
    struct aws_server_bootstrap *bootstrap,
    int error_code,
    void *user_data) {
    (void)bootstrap;

    struct aws_socks5_server *server = (struct aws_socks5_server *)user_data;
    bool should_shutdown = false;

    aws_mutex_lock(&server->lock);

    if (error_code != AWS_ERROR_SUCCESS) {
        server->sync.state = AWS_SOCKS5_SS_SHUTDOWN;
    } else {
        should_shutdown = server->sync.state == AWS_SOCKS5_SS_SHUTTING_DOWN;
        server->sync.state = AWS_SOCKS5_SS_LISTENING;
    }

    aws_mutex_unlock(&server->lock);

    if (server->config->on_setup) {
        (*server->config->on_setup)(server, error_code, server->config->user_data);
    }

    if (error_code != AWS_ERROR_SUCCESS) {
        aws_ref_count_release(&server->internal_ref_count); // Internal Ref Case 2
    }

    if (should_shutdown) {
        s_shut_down_server(server);
    }
}

struct aws_socks5_tunnel_options {
    struct aws_socks5_server *server;

    struct aws_channel *to_client_channel;

    uint64_t id;
};

static void s_aws_socks5_server_on_tunnel_shutdown(struct aws_socks5_tunnel *tunnel, int error_code, void *user_data) {
    (void)error_code;

    struct aws_socks5_server *server = (struct aws_socks5_server *)user_data;

    aws_mutex_lock(&server->lock);

    int was_present = false;
    aws_hash_table_remove(&server->sync.tunnels_by_id, &tunnel->id, NULL, &was_present);

    aws_mutex_unlock(&server->lock);

    if (was_present) {
        aws_ref_count_release(&tunnel->ref_count);
    }
}

static void s_aws_socks5_tunnel_destroy(void *user_data) {
    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)user_data;

    aws_string_destroy(tunnel->remote_host_name);
    aws_byte_buf_clean_up(&tunnel->handshake_data);
    aws_ref_count_release(&tunnel->server->internal_ref_count); // Internal Ref Case 3

    aws_mem_release(tunnel->allocator, tunnel);
}

static struct aws_socks5_tunnel *s_aws_socks5_tunnel_new(
    struct aws_allocator *allocator,
    struct aws_socks5_tunnel_options *options) {
    struct aws_socks5_tunnel *tunnel =
        (struct aws_socks5_tunnel *)aws_mem_calloc(allocator, 1, sizeof(struct aws_socks5_tunnel));

    tunnel->allocator = allocator;
    aws_ref_count_init(&tunnel->ref_count, tunnel, s_aws_socks5_tunnel_destroy);
    tunnel->id = options->id;
    tunnel->server = options->server;
    aws_ref_count_acquire(&tunnel->server->internal_ref_count); // Internal Ref Case 3

    tunnel->state = AWS_SOCKS5_TS_PENDING_METHOD_LIST;
    tunnel->selected_auth_method = AWS_SOCSK5_AMI_NO_ACCEPTABLE;
    tunnel->event_loop = aws_channel_get_event_loop(options->to_client_channel);
    tunnel->to_client = options->to_client_channel;

    aws_byte_buf_init(&tunnel->handshake_data, allocator, 512);

    tunnel->on_shutdown = s_aws_socks5_server_on_tunnel_shutdown;
    tunnel->on_shutdown_user_data = options->server;

    return tunnel;
}

static bool s_methods_contains(struct aws_byte_cursor methods, uint8_t method) {
    uint8_t *method_ptr = methods.ptr;
    for (size_t i = 0; i < methods.len; ++i, ++method_ptr) {
        if (*method_ptr == method) {
            return true;
        }
    }

    return false;
}

enum aws_socks5_version_code {
    AWS_SOCKS5_VERSION_5 = 0x05,
    AWS_SOCKS5_VERSION_BAD = 0x7F,
};

static int s_send_method_selection(struct aws_socks5_tunnel *tunnel, enum aws_socks5_auth_method_ids method) {
    tunnel->selected_auth_method = method;

    struct aws_io_message *message =
        aws_channel_acquire_message_from_pool(tunnel->to_client, AWS_IO_MESSAGE_APPLICATION_DATA, 2);

    uint8_t version_code = (tunnel->server->config->fault_mode == AWS_SOCKS5_SFM_BAD_VERSION)
                               ? (uint8_t)AWS_SOCKS5_VERSION_BAD
                               : (uint8_t)AWS_SOCKS5_VERSION_5;
    uint8_t method_selection_data[2] = {version_code, (uint8_t)method};

    struct aws_byte_cursor method_selection_data_cursor =
        aws_byte_cursor_from_array(method_selection_data, AWS_ARRAY_SIZE(method_selection_data));
    aws_byte_buf_append(&message->message_data, &method_selection_data_cursor);

    if (aws_channel_slot_send_message(tunnel->to_client_handler.slot, message, AWS_CHANNEL_DIR_WRITE)) {
        aws_mem_release(message->allocator, message);
        return AWS_OP_ERR;
    }

    return AWS_OP_SUCCESS;
}

static int s_handle_pending_method_list(struct aws_socks5_tunnel *tunnel, struct aws_io_message *message) {
    struct aws_byte_cursor message_data;
    AWS_ZERO_STRUCT(message_data);
    message_data.len = message->message_data.len - message->copy_mark;
    message_data.ptr = message->message_data.buffer + message->copy_mark;

    aws_byte_buf_append_dynamic(&tunnel->handshake_data, &message_data);

    size_t handshake_data_len = tunnel->handshake_data.len;
    if (handshake_data_len < 2) {
        return AWS_OP_SUCCESS;
    }

    uint8_t num_methods = *(tunnel->handshake_data.buffer + 1);
    size_t expected_data_len = (size_t)(num_methods + 2);
    if (handshake_data_len < expected_data_len) {
        return AWS_OP_SUCCESS;
    }

    if (handshake_data_len != expected_data_len) {
        return aws_raise_error(AWS_IO_SOCKS5_PROTOCOL_FAILURE);
    }

    struct aws_byte_cursor methods = aws_byte_cursor_from_buf(&tunnel->handshake_data);
    aws_byte_cursor_advance(&methods, 2);

    enum aws_socks5_auth_method_ids selected_method = AWS_SOCSK5_AMI_NO_ACCEPTABLE;
    struct aws_socks5_server_auth_config *auth_config = tunnel->server->config->auth_config;
    if (auth_config->allow_basic_auth) {
        if (s_methods_contains(methods, AWS_SOCKS5_AMI_BASIC)) {
            selected_method = AWS_SOCKS5_AMI_BASIC;
        }
    }

    if (auth_config->allow_no_auth) {
        if (s_methods_contains(methods, AWS_SOCKS5_AMI_NONE)) {
            selected_method = AWS_SOCKS5_AMI_NONE;
        }
    }

    if (s_send_method_selection(tunnel, selected_method)) {
        return AWS_OP_ERR;
    }

    enum aws_socks5_tunnel_state new_state = (selected_method == AWS_SOCKS5_AMI_BASIC)
                                                 ? AWS_SOCKS5_TS_PENDING_BASIC_AUTH_RECORD
                                                 : AWS_SOCKS5_TS_PENDING_COMMAND;
    s_aws_socks5_tunnel_change_state(tunnel, new_state);

    return AWS_OP_SUCCESS;
}

static int s_handle_basic_auth_record(struct aws_socks5_tunnel *tunnel, struct aws_io_message *message) {
    struct aws_byte_cursor message_data;
    AWS_ZERO_STRUCT(message_data);
    message_data.len = message->message_data.len - message->copy_mark;
    message_data.ptr = message->message_data.buffer + message->copy_mark;

    aws_byte_buf_append_dynamic(&tunnel->handshake_data, &message_data);

    size_t handshake_data_len = tunnel->handshake_data.len;
    if (handshake_data_len < 2) {
        return AWS_OP_SUCCESS;
    }

    size_t username_length = tunnel->handshake_data.buffer[1];
    if (handshake_data_len < username_length + 3) {
        return AWS_OP_SUCCESS;
    }

    size_t password_length = tunnel->handshake_data.buffer[username_length + 2];
    size_t required_record_length = username_length + password_length + 3;
    if (handshake_data_len < required_record_length) {
        return AWS_OP_SUCCESS;
    }

    if (handshake_data_len > required_record_length) {
        return aws_raise_error(AWS_IO_SOCKS5_PROTOCOL_FAILURE);
    }

    struct aws_byte_cursor username_cursor =
        aws_byte_cursor_from_array(tunnel->handshake_data.buffer + 2, username_length);
    struct aws_byte_cursor password_cursor =
        aws_byte_cursor_from_array(tunnel->handshake_data.buffer + username_length + 3, password_length);
    struct aws_byte_cursor expected_username_cursor =
        aws_byte_cursor_from_buf(&tunnel->server->config->auth_config->basic_username);
    struct aws_byte_cursor expected_password_cursor =
        aws_byte_cursor_from_buf(&tunnel->server->config->auth_config->basic_password);
    uint8_t response_byte = 0x01;

    if (aws_byte_cursor_eq(&username_cursor, &expected_username_cursor) &&
        aws_byte_cursor_eq(&password_cursor, &expected_password_cursor)) {
        response_byte = 0x00;
    }

    struct aws_io_message *result_message =
        aws_channel_acquire_message_from_pool(tunnel->to_client, AWS_IO_MESSAGE_APPLICATION_DATA, 2);

    uint8_t auth_result_data[2] = {0x01, response_byte};

    struct aws_byte_cursor auth_result_data_cursor =
        aws_byte_cursor_from_array(auth_result_data, AWS_ARRAY_SIZE(auth_result_data));
    aws_byte_buf_append(&result_message->message_data, &auth_result_data_cursor);

    if (aws_channel_slot_send_message(tunnel->to_client_handler.slot, result_message, AWS_CHANNEL_DIR_WRITE)) {
        aws_mem_release(result_message->allocator, result_message);
        return AWS_OP_ERR;
    }

    s_aws_socks5_tunnel_change_state(tunnel, AWS_SOCKS5_TS_PENDING_COMMAND);

    return AWS_OP_SUCCESS;
}

static int s_socks5_tunnel_to_remote_handler_process_read_message(
    struct aws_channel_handler *handler,
    struct aws_channel_slot *slot,
    struct aws_io_message *message) {
    (void)slot;

    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)handler->impl;
    if (tunnel->state != AWS_SOCKS5_TS_PASS_THROUGH) {
        // not necessarily invalid, but we don't want to handle it (during shut down)
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    // write it to the client channel
    if (aws_channel_slot_send_message(tunnel->to_client_handler.slot, message, AWS_CHANNEL_DIR_WRITE)) {
        s_aws_socks5_tunnel_shutdown(tunnel, aws_last_error());
        aws_mem_release(message->allocator, message);
    }

    return AWS_OP_SUCCESS;
}

static int s_socks5_tunnel_to_remote_handler_shutdown(
    struct aws_channel_handler *handler,
    struct aws_channel_slot *slot,
    enum aws_channel_direction dir,
    int error_code,
    bool free_scarce_resources_immediately) {

    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)handler->impl;
    s_aws_socks5_tunnel_shut_down(tunnel, error_code);

    return aws_channel_slot_on_handler_shutdown_complete(slot, dir, error_code, free_scarce_resources_immediately);
}

static size_t s_socks5_tunnel_to_remote_handler_initial_window_size(struct aws_channel_handler *handler) {
    (void)handler;

    return SIZE_MAX;
}

static size_t s_socks5_tunnel_to_remote_handler_message_overhead(struct aws_channel_handler *handler) {
    (void)handler;

    return 0;
}

static void s_socks5_tunnel_to_remote_handler_destroy(struct aws_channel_handler *handler) {
    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)handler->impl;
    s_aws_socks5_tunnel_on_channel_destroyed(tunnel, tunnel->to_remote);
}

static struct aws_channel_handler_vtable s_socks5_tunnel_to_remote_handler_vtable;

static void s_send_connect_response(struct aws_socks5_tunnel *tunnel, enum aws_socks5_connect_response_code code) {
    struct aws_io_message *message =
        aws_channel_acquire_message_from_pool(tunnel->to_client, AWS_IO_MESSAGE_APPLICATION_DATA, 256);

    uint8_t response_data[] = {0x05, (uint8_t)code, 0x00, AWS_SOCKS5_AT_IPV4, 0x7F, 0x00, 0x00, 0x01, 0x00, 0x00};

    struct aws_byte_cursor response_cursor = aws_byte_cursor_from_array(response_data, AWS_ARRAY_SIZE(response_data));
    aws_byte_buf_append(&message->message_data, &response_cursor);

    if (aws_channel_slot_send_message(tunnel->to_client_handler.slot, message, AWS_CHANNEL_DIR_WRITE)) {
        aws_mem_release(message->allocator, message);
    }
}

static void s_aws_socks5_tunnel_on_remote_channel_setup_fn(
    struct aws_client_bootstrap *bootstrap,
    int error_code,
    struct aws_channel *channel,
    void *user_data) {
    (void)bootstrap;

    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)user_data;
    tunnel->pending_remote = false;

    if (error_code != AWS_OP_SUCCESS) {
        s_aws_socks5_tunnel_shutdown(tunnel, error_code);
        return;
    }

    tunnel->to_remote = channel;

    struct aws_channel_slot *slot = aws_channel_slot_new(channel);

    struct aws_channel_handler *to_remote_handler = &tunnel->to_remote_handler;
    to_remote_handler->vtable = &s_socks5_tunnel_to_remote_handler_vtable;
    to_remote_handler->alloc = tunnel->allocator;
    to_remote_handler->impl = tunnel;
    to_remote_handler->slot = slot;

    aws_channel_slot_insert_end(channel, slot);

    aws_channel_slot_set_handler(slot, &tunnel->to_remote_handler);

    if (tunnel->state == AWS_SOCKS5_TS_SHUTTING_DOWN) {
        aws_channel_shutdown(channel, AWS_IO_SOCKS5_INTERNAL_FAILURE);
    } else {
        s_aws_socks5_tunnel_change_state(tunnel, AWS_SOCKS5_TS_PASS_THROUGH);
    }

    if (tunnel->state == AWS_SOCKS5_TS_PASS_THROUGH) {
        s_send_connect_response(tunnel, AWS_SOCKS5_CRC_SUCCEEDED);
    } else {
        s_send_connect_response(tunnel, AWS_SOCKS5_CRC_HOST_UNREACHABLE);
    }
}

static void s_aws_client_bootstrap_on_channel_shutdown_fn(
    struct aws_client_bootstrap *bootstrap,
    int error_code,
    struct aws_channel *channel,
    void *user_data) {
    (void)bootstrap;
    (void)channel;

    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)user_data;
    s_aws_socks5_tunnel_update_error_code(tunnel, error_code);
}

static int s_aws_socks5_tunnel_connect_to_remote(struct aws_socks5_tunnel *tunnel) {
    struct aws_socket_options socket_options;
    AWS_ZERO_STRUCT(socket_options);
    socket_options.type = AWS_SOCKET_STREAM;
    socket_options.domain = AWS_SOCKET_IPV4;
    socket_options.connect_timeout_ms = 10000;

    struct aws_socket_channel_bootstrap_options connect_options;
    AWS_ZERO_STRUCT(connect_options);
    connect_options.bootstrap = tunnel->server->config->to_remote_bootstrap;
    connect_options.host_name = aws_string_c_str(tunnel->remote_host_name);
    connect_options.port = tunnel->remote_port;
    connect_options.socket_options = &socket_options;
    connect_options.tls_options = NULL;
    connect_options.creation_callback = NULL;
    connect_options.setup_callback = s_aws_socks5_tunnel_on_remote_channel_setup_fn;
    connect_options.shutdown_callback = s_aws_client_bootstrap_on_channel_shutdown_fn;
    connect_options.enable_read_back_pressure = false;
    connect_options.user_data = tunnel;
    connect_options.requested_event_loop = tunnel->event_loop;

    tunnel->pending_remote = true;
    if (aws_client_bootstrap_new_socket_channel(&connect_options)) {
        tunnel->pending_remote = false;
        return AWS_OP_ERR;
    }

    s_aws_socks5_tunnel_change_state(tunnel, AWS_SOCKS5_TS_PENDING_REMOTE_CONNECTION);

    return AWS_OP_SUCCESS;
}

static int s_handle_command(struct aws_socks5_tunnel *tunnel, struct aws_io_message *message) {
    struct aws_byte_cursor message_data;
    AWS_ZERO_STRUCT(message_data);
    message_data.len = message->message_data.len - message->copy_mark;
    message_data.ptr = message->message_data.buffer + message->copy_mark;

    aws_byte_buf_append_dynamic(&tunnel->handshake_data, &message_data);

    size_t handshake_data_len = tunnel->handshake_data.len;
    if (handshake_data_len < 5) {
        return AWS_OP_SUCCESS;
    }

    uint8_t command = tunnel->handshake_data.buffer[1];
    if (command != AWS_SOCKS5_COMMAND_CONNECT) {
        return aws_raise_error(AWS_ERROR_UNIMPLEMENTED);
    }

    uint8_t address_type = tunnel->handshake_data.buffer[3];
    if (address_type != AWS_SOCKS5_AT_DOMAIN_NAME) {
        return aws_raise_error(AWS_ERROR_UNIMPLEMENTED);
    }

    uint8_t address_length = tunnel->handshake_data.buffer[4];
    size_t expected_command_length = address_length + 7;
    if (handshake_data_len < expected_command_length) {
        return AWS_OP_SUCCESS;
    }

    if (handshake_data_len > expected_command_length) {
        return aws_raise_error(AWS_IO_SOCKS5_PROTOCOL_FAILURE);
    }

    enum aws_socks5_server_fault_mode fault_mode = tunnel->server->config->fault_mode;
    if (fault_mode == AWS_SOCKS5_SFM_REMOTE_UNAVAILABLE) {
        s_send_connect_response(tunnel, AWS_SOCKS5_CRC_HOST_UNREACHABLE);
        return AWS_OP_SUCCESS;
    }

    if (fault_mode == AWS_SOCKS5_SFM_REMOTE_TIMEOUT) {
        return AWS_OP_SUCCESS;
    }

    struct aws_byte_cursor remote_host_name =
        aws_byte_cursor_from_array(tunnel->handshake_data.buffer + 5, address_length);
    tunnel->remote_host_name = aws_string_new_from_cursor(tunnel->allocator, &remote_host_name);

    struct aws_byte_cursor port_cursor =
        aws_byte_cursor_from_array(tunnel->handshake_data.buffer + 5 + address_length, 2);
    aws_byte_cursor_read_be16(&port_cursor, &tunnel->remote_port);

    return s_aws_socks5_tunnel_connect_to_remote(tunnel);
}

static int s_handle_pass_through(struct aws_socks5_tunnel *tunnel, struct aws_io_message *message) {
    return aws_channel_slot_send_message(tunnel->to_remote_handler.slot, message, AWS_CHANNEL_DIR_WRITE);
}

static int s_socks5_tunnel_to_client_handler_process_read_message(
    struct aws_channel_handler *handler,
    struct aws_channel_slot *slot,
    struct aws_io_message *message) {
    (void)slot;

    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)handler->impl;
    int result = AWS_OP_SUCCESS;
    switch (tunnel->state) {
        case AWS_SOCKS5_TS_PENDING_METHOD_LIST:
            result = s_handle_pending_method_list(tunnel, message);
            break;

        case AWS_SOCKS5_TS_PENDING_BASIC_AUTH_RECORD:
            result = s_handle_basic_auth_record(tunnel, message);
            break;

        case AWS_SOCKS5_TS_PENDING_COMMAND:
            result = s_handle_command(tunnel, message);
            break;

        case AWS_SOCKS5_TS_PENDING_REMOTE_CONNECTION:
            // should never happen
            return aws_raise_error(AWS_ERROR_INVALID_STATE);

        case AWS_SOCKS5_TS_PASS_THROUGH:
            // write it to the remote channel
            result = s_handle_pass_through(tunnel, message);
            if (!result) {
                message = NULL;
            }
            break;

        default:
            // not necessarily invalid, but we don't want to handle it (during shut down)
            return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    if (result != AWS_OP_SUCCESS) {
        s_aws_socks5_tunnel_shutdown(tunnel, aws_last_error());
    }

    if (message) {
        aws_mem_release(message->allocator, message);
    }

    return AWS_OP_SUCCESS;
}

static int s_socks5_tunnel_to_client_handler_shutdown(
    struct aws_channel_handler *handler,
    struct aws_channel_slot *slot,
    enum aws_channel_direction dir,
    int error_code,
    bool free_scarce_resources_immediately) {

    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)handler->impl;
    s_aws_socks5_tunnel_shut_down(tunnel, error_code);

    return aws_channel_slot_on_handler_shutdown_complete(slot, dir, error_code, free_scarce_resources_immediately);
}

static size_t s_socks5_tunnel_to_client_handler_initial_window_size(struct aws_channel_handler *handler) {
    (void)handler;

    return SIZE_MAX;
}

static size_t s_socks5_tunnel_to_client_handler_message_overhead(struct aws_channel_handler *handler) {
    (void)handler;

    return 0;
}

static void s_socks5_tunnel_to_client_handler_destroy(struct aws_channel_handler *handler) {
    struct aws_socks5_tunnel *tunnel = (struct aws_socks5_tunnel *)handler->impl;
    s_aws_socks5_tunnel_on_channel_destroyed(tunnel, tunnel->to_client);
}

static struct aws_channel_handler_vtable s_socks5_tunnel_to_client_handler_vtable;

static void s_aws_socks5_server_init_vtables(void) {
    AWS_ZERO_STRUCT(s_socks5_tunnel_to_remote_handler_vtable);
    s_socks5_tunnel_to_remote_handler_vtable.process_read_message =
        s_socks5_tunnel_to_remote_handler_process_read_message;
    s_socks5_tunnel_to_remote_handler_vtable.process_write_message = NULL;
    s_socks5_tunnel_to_remote_handler_vtable.increment_read_window = NULL;
    s_socks5_tunnel_to_remote_handler_vtable.shutdown = s_socks5_tunnel_to_remote_handler_shutdown;
    s_socks5_tunnel_to_remote_handler_vtable.initial_window_size =
        s_socks5_tunnel_to_remote_handler_initial_window_size;
    s_socks5_tunnel_to_remote_handler_vtable.message_overhead = s_socks5_tunnel_to_remote_handler_message_overhead;
    s_socks5_tunnel_to_remote_handler_vtable.destroy = s_socks5_tunnel_to_remote_handler_destroy;
    s_socks5_tunnel_to_remote_handler_vtable.reset_statistics = NULL;
    s_socks5_tunnel_to_remote_handler_vtable.gather_statistics = NULL;
    s_socks5_tunnel_to_remote_handler_vtable.trigger_read = NULL;

    AWS_ZERO_STRUCT(s_socks5_tunnel_to_client_handler_vtable);
    s_socks5_tunnel_to_client_handler_vtable.process_read_message =
        s_socks5_tunnel_to_client_handler_process_read_message;
    s_socks5_tunnel_to_client_handler_vtable.process_write_message = NULL;
    s_socks5_tunnel_to_client_handler_vtable.increment_read_window = NULL;
    s_socks5_tunnel_to_client_handler_vtable.shutdown = s_socks5_tunnel_to_client_handler_shutdown;
    s_socks5_tunnel_to_client_handler_vtable.initial_window_size =
        s_socks5_tunnel_to_client_handler_initial_window_size;
    s_socks5_tunnel_to_client_handler_vtable.message_overhead = s_socks5_tunnel_to_client_handler_message_overhead;
    s_socks5_tunnel_to_client_handler_vtable.destroy = s_socks5_tunnel_to_client_handler_destroy;
    s_socks5_tunnel_to_client_handler_vtable.reset_statistics = NULL;
    s_socks5_tunnel_to_client_handler_vtable.gather_statistics = NULL;
    s_socks5_tunnel_to_client_handler_vtable.trigger_read = NULL;
}

static void s_aws_socks5_server_bootstrap_on_accept_channel_setup_fn(
    struct aws_server_bootstrap *bootstrap,
    int error_code,
    struct aws_channel *channel,
    void *user_data) {

    (void)bootstrap;

    if (error_code != AWS_ERROR_SUCCESS) {
        return; // Nothing to do
    }

    struct aws_socks5_server *server = (struct aws_socks5_server *)user_data;

    struct aws_socks5_tunnel_options tunnel_options;
    AWS_ZERO_STRUCT(tunnel_options);
    tunnel_options.server = server;
    tunnel_options.to_client_channel = channel;
    tunnel_options.id = 0;

    aws_mutex_lock(&server->lock);

    tunnel_options.id = server->sync.next_id++;
    struct aws_socks5_tunnel *tunnel = s_aws_socks5_tunnel_new(server->allocator, &tunnel_options);
    aws_hash_table_put(&server->sync.tunnels_by_id, &tunnel->id, tunnel, NULL);
    server->sync.connections_created_count++;

    aws_mutex_unlock(&server->lock);

    struct aws_channel_slot *slot = aws_channel_slot_new(channel);

    struct aws_channel_handler *to_client_handler = &tunnel->to_client_handler;
    to_client_handler->vtable = &s_socks5_tunnel_to_client_handler_vtable;
    to_client_handler->alloc = server->allocator;
    to_client_handler->impl = tunnel;
    to_client_handler->slot = slot;

    aws_channel_slot_insert_end(channel, slot);

    aws_channel_slot_set_handler(slot, &tunnel->to_client_handler);
}

static void s_aws_socks5_server_bootstrap_on_accept_channel_shutdown_fn(
    struct aws_server_bootstrap *bootstrap,
    int error_code,
    struct aws_channel *channel,
    void *user_data) {
    (void)error_code;
    (void)bootstrap;
    (void)channel;
    (void)user_data;
}

static void s_aws_socks5_server_bootstrap_on_server_listener_destroy_fn(
    struct aws_server_bootstrap *bootstrap,
    void *user_data) {
    (void)bootstrap;

    struct aws_socks5_server *server = (struct aws_socks5_server *)user_data;

    aws_ref_count_release(&server->internal_ref_count); // Internal Ref Case 2
}

static int aws_socks5_server_begin_accept(struct aws_socks5_server *server) {
    if (!server) {
        return aws_raise_error(AWS_ERROR_INVALID_ARGUMENT);
    }

    bool can_proceed = false;
    aws_mutex_lock(&server->lock);
    can_proceed = server->sync.state == AWS_SOCKS5_SS_INITIAL;
    if (can_proceed) {
        server->sync.state = AWS_SOCKS5_SS_PENDING_LISTENER;
    }
    aws_mutex_unlock(&server->lock);

    if (!can_proceed) {
        return aws_raise_error(AWS_ERROR_INVALID_STATE);
    }

    aws_ref_count_acquire(&server->internal_ref_count); // Internal Ref Case 2

    struct aws_server_socket_channel_bootstrap_options listener_options;
    AWS_ZERO_STRUCT(listener_options);
    listener_options.bootstrap = server->config->listener_bootstrap;
    listener_options.host_name = aws_string_c_str(server->config->host_name);
    listener_options.port = server->config->port;
    listener_options.socket_options = &server->config->socket_options;
    listener_options.tls_options = NULL;
    listener_options.setup_callback = s_aws_socks5_server_bootstrap_on_listener_setup_fn;
    listener_options.incoming_callback = s_aws_socks5_server_bootstrap_on_accept_channel_setup_fn;
    listener_options.shutdown_callback = s_aws_socks5_server_bootstrap_on_accept_channel_shutdown_fn;
    listener_options.destroy_callback = s_aws_socks5_server_bootstrap_on_server_listener_destroy_fn;
    listener_options.enable_read_back_pressure = false;
    listener_options.user_data = server;

    struct aws_socket *listener = aws_server_bootstrap_new_socket_listener(&listener_options);
    if (!listener) {
        goto error;
    }

    aws_mutex_lock(&server->lock);
    server->sync.listener_socket = listener;
    aws_mutex_unlock(&server->lock);

    return AWS_OP_SUCCESS;

error:

    aws_ref_count_release(&server->internal_ref_count); // Internal Ref Case 2

    return AWS_OP_ERR;
}

static uint32_t aws_socks5_server_get_listener_port(struct aws_socks5_server *server) {
    uint32_t port = 0;

    aws_mutex_lock(&server->lock);
    port = server->sync.listener_socket->local_endpoint.port;
    aws_mutex_unlock(&server->lock);

    return port;
}

static size_t aws_socks5_server_get_connections_created(struct aws_socks5_server *server) {
    size_t count = 0;

    aws_mutex_lock(&server->lock);
    count = server->sync.connections_created_count;
    aws_mutex_unlock(&server->lock);

    return count;
}

static void s_aws_socks5_server_test_context_on_server_setup(
    struct aws_socks5_server *server,
    int error_code,
    void *user_data) {
    (void)server;
    (void)error_code;

    struct aws_socks5_server_test_context *context = (struct aws_socks5_server_test_context *)user_data;

    aws_mutex_lock(&context->lock);
    context->sync.server_setup = true;
    context->sync.setup_error_code = error_code;
    if (error_code != AWS_ERROR_SUCCESS) {
        context->sync.server_shutdown = true;
    }
    aws_condition_variable_notify_all(&context->signal);
    aws_mutex_unlock(&context->lock);
}

static void s_aws_socks5_server_test_context_on_server_destroy(struct aws_socks5_server *server, void *user_data) {
    (void)server;

    struct aws_socks5_server_test_context *context = (struct aws_socks5_server_test_context *)user_data;

    aws_mutex_lock(&context->lock);
    context->sync.server_shutdown = true;
    aws_condition_variable_notify_all(&context->signal);
    aws_mutex_unlock(&context->lock);
}

static void aws_socks5_server_test_context_init(
    struct aws_socks5_server_test_context *context,
    struct aws_allocator *allocator,
    struct aws_socks5_server_test_context_options *options) {
    AWS_ZERO_STRUCT(*context);

    context->allocator = allocator;

    if (options && options->elg != NULL) {
        context->elg = aws_event_loop_group_acquire(options->elg);
    } else {
        struct aws_event_loop_group_options elg_options;
        AWS_ZERO_STRUCT(elg_options);

        context->elg = aws_event_loop_group_new(allocator, &elg_options);
    }

    struct aws_host_resolver_default_options hr_options;
    AWS_ZERO_STRUCT(hr_options);
    hr_options.max_entries = 32;
    hr_options.el_group = context->elg;

    context->resolver = aws_host_resolver_new_default(allocator, &hr_options);

    struct aws_client_bootstrap_options client_bootstrap_options;
    AWS_ZERO_STRUCT(client_bootstrap_options);
    client_bootstrap_options.event_loop_group = context->elg;
    client_bootstrap_options.host_resolver = context->resolver;

    context->client_bootstrap = aws_client_bootstrap_new(context->allocator, &client_bootstrap_options);

    context->server_bootstrap = aws_server_bootstrap_new(context->allocator, context->elg);

    aws_mutex_init(&context->lock);
    aws_condition_variable_init(&context->signal);

    struct aws_socks5_server_options server_options;
    AWS_ZERO_STRUCT(server_options);
    server_options.elg = context->elg;
    server_options.to_remote_bootstrap = context->client_bootstrap;
    server_options.listener_bootstrap = context->server_bootstrap;
    server_options.host_name = "127.0.0.1";
    server_options.port = 0;
    server_options.socket_options.type = AWS_SOCKET_STREAM;
    server_options.socket_options.domain = AWS_SOCKET_IPV4;
    server_options.auth_options.allow_no_auth = true;
    server_options.auth_options.allow_basic_auth = false;
    server_options.fault_mode = options != NULL ? options->fault_mode : AWS_SOCKS5_SFM_NONE;
    server_options.on_setup = s_aws_socks5_server_test_context_on_server_setup;
    server_options.on_destroy = s_aws_socks5_server_test_context_on_server_destroy;
    server_options.user_data = context;

    if (options && options->override_auth_options) {
        server_options.auth_options = *options->override_auth_options;
    }

    context->server = aws_socks5_server_new(allocator, &server_options);

    // use the APIs to prevent unused funtion warning
    aws_socks5_server_acquire(context->server);
    aws_socks5_server_release(context->server);

    aws_socks5_server_begin_accept(context->server);
}

static bool s_check_server_setup(void *user_data) {
    struct aws_socks5_server_test_context *context = (struct aws_socks5_server_test_context *)user_data;

    return context->sync.server_setup;
}

static void aws_socks5_server_test_context_wait_on_server_setup(struct aws_socks5_server_test_context *context) {
    aws_mutex_lock(&context->lock);
    aws_condition_variable_wait_pred(&context->signal, &context->lock, s_check_server_setup, context);
    aws_mutex_unlock(&context->lock);
}

static bool s_check_server_destroyed(void *user_data) {
    struct aws_socks5_server_test_context *context = (struct aws_socks5_server_test_context *)user_data;

    return context->sync.server_shutdown;
}

static void s_aws_socks5_server_test_context_wait_on_server_shutdown(struct aws_socks5_server_test_context *context) {
    aws_mutex_lock(&context->lock);
    aws_condition_variable_wait_pred(&context->signal, &context->lock, s_check_server_destroyed, context);
    aws_mutex_unlock(&context->lock);
}

static void aws_socks5_server_test_context_clean_up(struct aws_socks5_server_test_context *context) {

    aws_socks5_server_release(context->server);

    s_aws_socks5_server_test_context_wait_on_server_shutdown(context);

    aws_server_bootstrap_release(context->server_bootstrap);
    aws_client_bootstrap_release(context->client_bootstrap);
    aws_host_resolver_release(context->resolver);
    aws_event_loop_group_release(context->elg);

    aws_condition_variable_clean_up(&context->signal);
    aws_mutex_clean_up(&context->lock);
}

AWS_EXTERN_C_END

#endif /* SOCKS5_SERVER_H */
